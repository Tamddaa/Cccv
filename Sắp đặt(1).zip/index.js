import { Client, Collection, GatewayIntentBits } from 'discord.js';
import { fileURLToPath, pathToFileURL } from 'url';
import { dirname, join } from 'path';
import { readdirSync } from 'fs';
import config from './config.json' assert { type: 'json' };

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Tạo Discord client
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.DirectMessages
  ]
});

// Collection để lưu commands
client.commands = new Collection();

// Load commands từ thư mục commands
const commandsPath = join(__dirname, 'commands');
const commandFiles = readdirSync(commandsPath).filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
  const filePath = join(commandsPath, file);
  const fileUrl = pathToFileURL(filePath).href;
  
  try {
    const command = await import(fileUrl);
    const commandData = command.default;
    
    if ('data' in commandData && 'execute' in commandData) {
      client.commands.set(commandData.data.name, commandData);
      console.log(`✅ Loaded command: ${commandData.data.name}`);
    } else {
      console.log(`⚠️  Command ${file} is missing required "data" or "execute" property.`);
    }
  } catch (error) {
    console.error(`❌ Error loading command ${file}:`, error);
  }
}

// Event: Bot ready
client.once('ready', () => {
  console.log(`🤖 Bot đã sẵn sàng! Đăng nhập với tên: ${client.user.tag}`);
  console.log(`📊 Đang phục vụ ${client.guilds.cache.size} server(s)`);
  
  // Set bot status
  client.user.setActivity('Việt hóa file cấu hình', { type: 'WATCHING' });
});

// Event: Interaction (slash commands)
client.on('interactionCreate', async interaction => {
  if (!interaction.isChatInputCommand()) return;

  const command = client.commands.get(interaction.commandName);
  if (!command) {
    console.error(`❌ Command ${interaction.commandName} not found.`);
    return;
  }

  try {
    await command.execute(interaction);
  } catch (error) {
    console.error(`❌ Error executing command ${interaction.commandName}:`, error);
    
    const errorMessage = {
      content: '❌ Đã xảy ra lỗi khi thực hiện lệnh này!',
      ephemeral: true
    };

    if (interaction.replied || interaction.deferred) {
      await interaction.followUp(errorMessage);
    } else {
      await interaction.reply(errorMessage);
    }
  }
});

// Error handling
client.on('error', error => {
  console.error('❌ Discord client error:', error);
});

process.on('unhandledRejection', error => {
  console.error('❌ Unhandled promise rejection:', error);
});

// Login bot
client.login(config.BOT_TOKEN).catch(error => {
  console.error('❌ Failed to login:', error);
  process.exit(1);
});