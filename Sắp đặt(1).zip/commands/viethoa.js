import { SlashCommandBuilder, AttachmentBuilder, EmbedBuilder, Colors } from 'discord.js';
import axios from 'axios';
import yaml from 'js-yaml';
import config from '../config.json' assert { type: 'json' };
import { translateText } from '../utils/translator.js';
import { translationQueue } from '../utils/queue.js';
import { saveTemporaryFile, scheduleFileDeletion } from '../utils/fileManager.js';

// Helper functions
function formatFileSize(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(2)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function createProgressBar(percentage) {
  const totalBlocks = 14;
  const filled = Math.round((percentage / 100) * totalBlocks);
  return `${'▰'.repeat(filled)}${'▱'.repeat(totalBlocks - filled)}`;
}

function formatTime(seconds) {
  if (seconds < 60) return `${seconds.toFixed(1)}s`;
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = Math.round(seconds % 60);
  return `${minutes}m ${remainingSeconds}s`;
}

// Embed builders
function createQueuedEmbed(file, position) {
  return new EmbedBuilder()
    .setColor(Colors.Yellow)
    .setTitle('📋 Đã thêm vào hàng đợi')
    .setDescription(
      `**Tên file:** \`${file.name}\`\n` +
      `**Định dạng:** \`${file.name.split('.').pop().toUpperCase()}\`\n` +
      `**Kích thước:** \`${formatFileSize(file.size)}\`\n` +
      `**Vị trí trong hàng đợi:** \`#${position}\`\n\n` +
      `*File sẽ được xử lý khi đến lượt!*`
    )
    .setTimestamp();
}

function createProgressEmbed(file, progressData, startTime) {
  const { progress, processedLines, totalLines } = progressData;
  const elapsed = (Date.now() - startTime) / 1000;
  const eta = progress > 0 ? (elapsed / progress) * (100 - progress) : 0;

  return new EmbedBuilder()
    .setColor(progress < 30 ? Colors.Red : progress < 70 ? Colors.Yellow : Colors.Green)
    .setTitle('⏳ Đang Việt hóa...')
    .setDescription(
      `**File:** \`${file.name}\`\n` +
      `**Tiến độ:** \`${progress}%\`\n` +
      `\`${createProgressBar(progress)}\`\n` +
      `**Dòng đã xử lý:** \`${processedLines}/${totalLines}\`\n` +
      `**Thời gian còn lại:** \`${formatTime(eta)}\``
    )
    .setTimestamp();
}

function createSuccessEmbed(file, totalLines, processingTime) {
  return new EmbedBuilder()
    .setColor(Colors.Green)
    .setTitle('✨ Việt hóa hoàn tất!')
    .addFields(
      {
        name: '📂 Thông tin file',
        value:
          `**Tên file:** \`${file.name}\`\n` +
          `**Định dạng:** \`${file.name.split('.').pop().toUpperCase()}\`\n` +
          `**Kích thước:** \`${formatFileSize(file.size)}\``,
        inline: true
      },
      {
        name: '📊 Thống kê',
        value:
          `**Tổng dòng:** \`${totalLines}\`\n` +
          `**Thời gian xử lý:** \`${formatTime(processingTime)}\`\n` +
          `**Tự động xóa sau:** \`${config.FILE_CLEANUP_MINUTES} phút\``,
        inline: true
      }
    )
    .setDescription('✅ File đã được gửi qua tin nhắn riêng và sẽ tự động xóa sau 5 phút.')
    .setTimestamp();
}

function createErrorEmbed(message) {
  return new EmbedBuilder()
    .setColor(Colors.Red)
    .setTitle('❌ Lỗi xử lý file')
    .setDescription(message || 'Đã xảy ra lỗi không xác định. Vui lòng thử lại sau.')
    .setTimestamp();
}

// Main command
export default {
  data: new SlashCommandBuilder()
    .setName('viethoa')
    .setDescription('Việt hóa file cấu hình (.yml/.yaml/.json/.properties/.txt/.csv)')
    .addAttachmentOption(option =>
      option.setName('file')
        .setDescription('File cần Việt hóa')
        .setRequired(true)
    ),

  async execute(interaction) {
    // Kiểm tra quyền (nếu có cấu hình)
    if (Array.isArray(config.ALLOWED_ROLES) && config.ALLOWED_ROLES.length > 0) {
      const hasPermission = interaction.member?.roles?.cache?.some(role => 
        config.ALLOWED_ROLES.includes(role.id)
      );
      
      if (!hasPermission) {
        return interaction.reply({
          embeds: [createErrorEmbed('⛔ Bạn không có quyền sử dụng lệnh này.')],
          ephemeral: true
        });
      }
    }

    const file = interaction.options.getAttachment('file');
    if (!file) {
      return interaction.reply({
        embeds: [createErrorEmbed('Không tìm thấy file đính kèm.')],
        ephemeral: true
      });
    }

    // Kiểm tra định dạng file
    const isValidFormat = config.SUPPORTED_FILES.some(ext => 
      file.name.toLowerCase().endsWith(ext)
    );
    
    if (!isValidFormat) {
      return interaction.reply({
        embeds: [createErrorEmbed(
          `Định dạng file không được hỗ trợ.\n` +
          `**Các định dạng hỗ trợ:** ${config.SUPPORTED_FILES.join(', ')}`
        )],
        ephemeral: true
      });
    }

    // Kiểm tra kích thước file
    const maxBytes = (config.MAX_FILE_SIZE_MB || 5) * 1024 * 1024;
    if (file.size > maxBytes) {
      return interaction.reply({
        embeds: [createErrorEmbed(
          `File quá lớn! Kích thước tối đa: ${config.MAX_FILE_SIZE_MB}MB`
        )],
        ephemeral: true
      });
    }

    // Tạo job và thêm vào hàng đợi
    const job = {
      interaction,
      file,
      user: interaction.user,
      execute: async (jobData) => {
        const startTime = Date.now();
        let lastUpdateTime = 0;

        try {
          // Tải nội dung file
          const response = await axios.get(file.url, { 
            responseType: 'text', 
            timeout: 90000 
          });
          
          const fileContent = response.data || '';
          const normalizedContent = String(fileContent).replace(/\t/g, '    ');
          
          // Bắt đầu dịch với progress callback
          const translatedContent = await translateText(normalizedContent, (progressData) => {
            const now = Date.now();
            // Chỉ cập nhật UI mỗi 2 giây để tránh spam
            if (now - lastUpdateTime > 2000) {
              lastUpdateTime = now;
              interaction.editReply({
                embeds: [createProgressEmbed(file, progressData, startTime)]
              }).catch(console.error);
            }
          });

          // Validate kết quả dịch theo định dạng file
          const fileExtension = file.name.split('.').pop().toLowerCase();
          try {
            if (fileExtension === 'json') {
              JSON.parse(translatedContent);
            } else if (fileExtension === 'yml' || fileExtension === 'yaml') {
              yaml.load(translatedContent);
            }
          } catch (parseError) {
            console.warn(`⚠️  Translated content may have format issues: ${parseError.message}`);
          }

          // Tạo file output
          const outputFileName = `translated_${file.name}`;
          const buffer = Buffer.from(translatedContent, 'utf8');
          const attachment = new AttachmentBuilder(buffer, { name: outputFileName });

          // Lưu file tạm và lên lịch xóa
          await saveTemporaryFile(outputFileName, translatedContent);
          scheduleFileDeletion(outputFileName, config.FILE_CLEANUP_MINUTES);

          // Gửi file qua DM
          await interaction.user.send({
            content: `📩 **File đã Việt hóa:** \`${file.name}\`\n` +
                    `⏰ File sẽ tự động xóa sau ${config.FILE_CLEANUP_MINUTES} phút.`,
            files: [attachment]
          });

          // Cập nhật embed thành công
          const processingTime = (Date.now() - startTime) / 1000;
          const totalLines = normalizedContent.split('\n').length;
          
          await interaction.editReply({
            embeds: [createSuccessEmbed(file, totalLines, processingTime)]
          });

        } catch (error) {
          console.error('❌ Job execution error:', error);
          await interaction.editReply({
            embeds: [createErrorEmbed(
              'Không thể hoàn tất việc Việt hóa. Vui lòng thử lại sau.\n' +
              `**Lỗi:** ${error.message}`
            )]
          });
          throw error;
        }
      }
    };

    // Reply ngay với thông tin hàng đợi
    const queueInfo = translationQueue.getQueueInfo();
    const position = queueInfo.queueLength + 1;
    
    await interaction.reply({
      embeds: [createQueuedEmbed(file, position)]
    });

    // Thêm job vào hàng đợi
    try {
      // Tải và validate file trước khi thêm vào queue
      const response = await axios.get(file.url, { 
        responseType: 'text', 
        timeout: 30000 
      });
      
      if (!response.data) {
        throw new Error('File rỗng hoặc không thể đọc được');
      }

      translationQueue.addJob(job);
    } catch (error) {
      console.error('❌ Error adding job to queue:', error);
      await interaction.editReply({
        embeds: [createErrorEmbed(
          'Không thể tải file từ Discord. Vui lòng thử lại.\n' +
          `**Lỗi:** ${error.message}`
        )]
      });
    }
  }
};