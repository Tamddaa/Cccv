import EventEmitter from 'events';

class TranslationQueue extends EventEmitter {
  constructor() {
    super();
    this.queue = [];
    this.processing = false;
    this.currentJob = null;
  }

  // Thêm job vào hàng đợi
  addJob(job) {
    const queuePosition = this.queue.length + 1;
    const jobWithId = {
      ...job,
      id: this.generateJobId(),
      addedAt: Date.now(),
      position: queuePosition
    };

    this.queue.push(jobWithId);
    this.emit('jobAdded', jobWithId);
    
    console.log(`📋 Added job ${jobWithId.id} to queue (position: ${queuePosition})`);
    
    // Bắt đầu xử lý nếu chưa có job nào đang chạy
    if (!this.processing) {
      this.processNext();
    }

    return jobWithId;
  }

  // Tạo ID duy nhất cho job
  generateJobId() {
    return `job_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  // Xử lý job tiếp theo trong hàng đợi
  async processNext() {
    if (this.processing || this.queue.length === 0) {
      return;
    }

    this.processing = true;
    this.currentJob = this.queue.shift();

    // Cập nhật vị trí cho các job còn lại
    this.queue.forEach((job, index) => {
      job.position = index + 1;
    });

    console.log(`⚡ Processing job ${this.currentJob.id}`);
    this.emit('jobStarted', this.currentJob);

    try {
      // Thực hiện job
      await this.currentJob.execute(this.currentJob);
      
      console.log(`✅ Job ${this.currentJob.id} completed successfully`);
      this.emit('jobCompleted', this.currentJob);
    } catch (error) {
      console.error(`❌ Job ${this.currentJob.id} failed:`, error);
      this.emit('jobFailed', this.currentJob, error);
    } finally {
      this.currentJob = null;
      this.processing = false;
      
      // Xử lý job tiếp theo nếu có
      if (this.queue.length > 0) {
        // Đợi một chút trước khi xử lý job tiếp theo
        setTimeout(() => this.processNext(), 1000);
      }
    }
  }

  // Lấy thông tin hàng đợi
  getQueueInfo() {
    return {
      queueLength: this.queue.length,
      processing: this.processing,
      currentJob: this.currentJob ? {
        id: this.currentJob.id,
        fileName: this.currentJob.file?.name,
        addedAt: this.currentJob.addedAt
      } : null,
      upcomingJobs: this.queue.map(job => ({
        id: job.id,
        fileName: job.file?.name,
        position: job.position,
        addedAt: job.addedAt
      }))
    };
  }

  // Xóa job khỏi hàng đợi (nếu chưa được xử lý)
  removeJob(jobId) {
    const index = this.queue.findIndex(job => job.id === jobId);
    if (index !== -1) {
      const removedJob = this.queue.splice(index, 1)[0];
      
      // Cập nhật vị trí cho các job còn lại
      this.queue.forEach((job, idx) => {
        job.position = idx + 1;
      });

      console.log(`🗑️  Removed job ${jobId} from queue`);
      this.emit('jobRemoved', removedJob);
      return true;
    }
    return false;
  }

  // Dừng xử lý hàng đợi
  stop() {
    this.processing = false;
    console.log('⏸️  Queue processing stopped');
  }

  // Tiếp tục xử lý hàng đợi
  resume() {
    if (!this.processing && this.queue.length > 0) {
      this.processNext();
      console.log('▶️  Queue processing resumed');
    }
  }

  // Xóa tất cả job trong hàng đợi
  clear() {
    const clearedJobs = this.queue.splice(0);
    console.log(`🧹 Cleared ${clearedJobs.length} jobs from queue`);
    this.emit('queueCleared', clearedJobs);
    return clearedJobs;
  }
}

// Tạo instance duy nhất của queue
export const translationQueue = new TranslationQueue();

// Log queue events
translationQueue.on('jobAdded', (job) => {
  console.log(`📋 Job added: ${job.file?.name} (Position: ${job.position})`);
});

translationQueue.on('jobStarted', (job) => {
  console.log(`⚡ Job started: ${job.file?.name}`);
});

translationQueue.on('jobCompleted', (job) => {
  console.log(`✅ Job completed: ${job.file?.name}`);
});

translationQueue.on('jobFailed', (job, error) => {
  console.log(`❌ Job failed: ${job.file?.name} - ${error.message}`);
});

export default translationQueue;