import axios from 'axios';
import crypto from 'crypto';
import config from '../config.json' assert { type: 'json' };

// Cache để lưu kết quả dịch
const translationCache = new Map();

// Tạo hash cho cache key
function createHash(text) {
  return crypto.createHash('sha256').update(text, 'utf8').digest('hex');
}

// Loại bỏ code fences từ response
function stripCodeFences(text) {
  return text
    .replace(/^\s*```(?:yaml|yml|json|properties|txt|csv)?\s*\n/i, '')
    .replace(/\s*```\s*$/i, '')
    .trim();
}

// Chia text thành các chunk theo dòng
export function splitIntoChunks(text, maxLines = 300) {
  const lines = text.replace(/\r\n/g, '\n').split('\n');
  const chunks = [];
  
  for (let i = 0; i < lines.length; i += maxLines) {
    const chunk = lines.slice(i, i + maxLines).join('\n');
    chunks.push(chunk);
  }
  
  return {
    chunks,
    totalLines: lines.length
  };
}

// Dịch một chunk text
export async function translateChunk(text, retries = 3) {
  const cacheKey = createHash(text);
  
  // Kiểm tra cache trước
  if (translationCache.has(cacheKey)) {
    return translationCache.get(cacheKey);
  }

  const requestBody = {
    model: 'google/gemini-2.0-flash-exp:free',
    messages: [
      { role: 'system', content: config.TRANSLATION_PROMPT },
      { role: 'user', content: text }
    ],
    temperature: 0.2
  };

  let lastError = null;
  
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const response = await axios.post('https://openrouter.ai/api/v1/chat/completions', requestBody, {
        headers: {
          'Authorization': `Bearer ${config.OPENROUTER_API_KEY}`,
          'Content-Type': 'application/json'
        },
        timeout: 90000
      });

      const translatedText = response.data?.choices?.[0]?.message?.content ?? '';
      const cleanedText = stripCodeFences(translatedText);
      
      // Lưu vào cache
      translationCache.set(cacheKey, cleanedText);
      
      return cleanedText;
    } catch (error) {
      lastError = error;
      console.error(`❌ Translation attempt ${attempt} failed:`, error?.response?.data || error?.message);
      
      if (attempt < retries) {
        // Đợi trước khi retry
        await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
      }
    }
  }

  throw lastError || new Error('Translation failed after all retries');
}

// Dịch toàn bộ text với progress callback
export async function translateText(text, onProgress) {
  const { chunks, totalLines } = splitIntoChunks(text, config.CHUNK_MAX_LINES || 300);
  const translatedChunks = [];
  let processedLines = 0;

  for (let i = 0; i < chunks.length; i++) {
    const chunk = chunks[i];
    const chunkLines = chunk.split('\n').length;
    
    try {
      const translatedChunk = await translateChunk(chunk);
      translatedChunks.push(translatedChunk);
      
      processedLines += chunkLines;
      const progress = Math.min(100, Math.round((processedLines / totalLines) * 100));
      
      if (onProgress) {
        onProgress({
          progress,
          processedLines: Math.min(processedLines, totalLines),
          totalLines,
          currentChunk: i + 1,
          totalChunks: chunks.length
        });
      }
    } catch (error) {
      console.error(`❌ Failed to translate chunk ${i + 1}:`, error);
      throw new Error(`Failed to translate chunk ${i + 1}: ${error.message}`);
    }
  }

  return translatedChunks.join('\n');
}

// Làm sạch cache định kỳ
setInterval(() => {
  if (translationCache.size > 1000) {
    translationCache.clear();
    console.log('🧹 Translation cache cleared');
  }
}, 30 * 60 * 1000); // Mỗi 30 phút