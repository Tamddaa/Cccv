import { promises as fs } from 'fs';
import { join } from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Thư mục lưu trữ file tạm
const TEMP_DIR = join(__dirname, '..', 'temp');

// Đảm bảo thư mục temp tồn tại
async function ensureTempDir() {
  try {
    await fs.access(TEMP_DIR);
  } catch {
    await fs.mkdir(TEMP_DIR, { recursive: true });
  }
}

// Lưu file tạm thời
export async function saveTemporaryFile(filename, content) {
  await ensureTempDir();
  const filePath = join(TEMP_DIR, filename);
  await fs.writeFile(filePath, content, 'utf8');
  return filePath;
}

// Đọc file tạm thời
export async function readTemporaryFile(filename) {
  const filePath = join(TEMP_DIR, filename);
  return await fs.readFile(filePath, 'utf8');
}

// Xóa file tạm thời
export async function deleteTemporaryFile(filename) {
  try {
    const filePath = join(TEMP_DIR, filename);
    await fs.unlink(filePath);
    console.log(`🗑️  Deleted temporary file: ${filename}`);
  } catch (error) {
    console.error(`❌ Error deleting file ${filename}:`, error);
  }
}

// Lên lịch xóa file sau một khoảng thời gian
export function scheduleFileDeletion(filename, delayMinutes = 5) {
  const delayMs = delayMinutes * 60 * 1000;
  
  setTimeout(async () => {
    await deleteTemporaryFile(filename);
  }, delayMs);
  
  console.log(`⏰ Scheduled deletion for ${filename} in ${delayMinutes} minutes`);
}

// Làm sạch tất cả file tạm cũ
export async function cleanupOldFiles() {
  try {
    await ensureTempDir();
    const files = await fs.readdir(TEMP_DIR);
    const now = Date.now();
    const maxAge = 30 * 60 * 1000; // 30 phút

    for (const file of files) {
      const filePath = join(TEMP_DIR, file);
      const stats = await fs.stat(filePath);
      
      if (now - stats.mtime.getTime() > maxAge) {
        await fs.unlink(filePath);
        console.log(`🧹 Cleaned up old file: ${file}`);
      }
    }
  } catch (error) {
    console.error('❌ Error during cleanup:', error);
  }
}

// Chạy cleanup định kỳ mỗi 15 phút
setInterval(cleanupOldFiles, 15 * 60 * 1000);